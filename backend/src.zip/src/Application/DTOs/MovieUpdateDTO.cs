﻿namespace backend.src.Application.DTOs;

public class MovieUpdateDTO : MovieCreateDTO
{
    public int Id { get; set; }
}
