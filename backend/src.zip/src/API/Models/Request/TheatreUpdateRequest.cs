﻿namespace backend.src.API.Models.Request;

public class TheatreUpdateRequest : TheatreCreateRequest
{
    public int Id { get; set; }
}
