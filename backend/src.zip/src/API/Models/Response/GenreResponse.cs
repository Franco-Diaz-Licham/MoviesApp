﻿namespace backend.src.API.Models.Response
{
    public class GenreResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
