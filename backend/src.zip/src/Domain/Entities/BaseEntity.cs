﻿namespace backend.src.Domain.Entities;

public abstract class BaseEntity
{
    public int Id { get; set; }
}
