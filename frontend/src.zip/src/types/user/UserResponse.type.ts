
export interface UserResponse {
    id: number;
    firstName: string;
    surname: string;
    email: string;
    displayName: string;
    token: string;
}