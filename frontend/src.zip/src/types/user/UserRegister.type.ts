export interface UserRegister {
    firstName: string;
    surname: string;
    displayName: string;
    email: string;
    password: string;
}
