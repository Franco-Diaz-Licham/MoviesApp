export interface LoginFormData {
    firstName?: string;
    surname?: string;
    displayName?: string;
    email: string;
    password?: string;
}
