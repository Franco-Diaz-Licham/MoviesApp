export interface UserUpdate {
    firstName: string;
    surname: string;
    email: string;
    displayName: string;
}
