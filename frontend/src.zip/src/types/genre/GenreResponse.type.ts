export interface GenreResponse {
    id: number;
    name: string;
    description: string;
}
