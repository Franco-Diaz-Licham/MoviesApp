import { GenreCreate } from "./GenreCreate.type";

export interface GenreUpdate extends GenreCreate {
    id: number;
}
