export default interface GenreFormData {
    id?: number;
    name: string;
    description: string;
}
