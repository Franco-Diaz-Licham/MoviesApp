export interface GenreCreate {
    name: string;
    description: string;
}
