export interface PhotoCreate {
    image: File[];
}
