
export interface PhotoResponse{
    id: string;
    publicUrl: string;
    publicId: string;
}