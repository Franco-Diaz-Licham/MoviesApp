export default interface CoordinateDTO {
    longitude: number;
    latitude: number;
}