import { TheatreCreate } from "./TheatreCreate.type";

export interface TheatreUpdate extends TheatreCreate {
    id: number;
}