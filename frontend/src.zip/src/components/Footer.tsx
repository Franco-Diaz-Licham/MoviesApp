
/** Footer component./ */
export default function Footer(){
    return <footer className="text-center fw-bold bg-dark text-white py-3">Movies App, By Franco Diaz</footer>
}